import App from './app/App.js'

window.addEventListener('load', () => {
  new App()
})
