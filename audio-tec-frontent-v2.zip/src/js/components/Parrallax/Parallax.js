import Rellax from 'Rellax'

class Parallax {
  constructor ($element) {
    new Rellax($element)
  }
}

export default Parallax
